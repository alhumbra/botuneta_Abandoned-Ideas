Outfoxies ROM Extractor
=======================

This Python script creates Japanese and international ROM ZIP sets from the
uncompressed main executable, main_uncompressed, included with the Arcade
Archives release of The Outfoxies.

Author: alhumbra
Distribution site: https://github.com/alhumbra/botuneta_Abandoned-Ideas


Requirements
------------

- Python 3.9 or later
- An uncompressed main_uncompressed file lawfully prepared by the user

hactool, key files, main decompile.bat, and other batch files are not included
in this distribution.

Before using the script, you must generate main_uncompressed yourself using
your own environment and lawfully obtained data.

The compressed main file cannot be used directly. If its NSO sections have not
been decompressed, the script displays an error and exits.


Included files
--------------

extract_outfoxies_roms.py
README_JA.txt
README_EN.txt
LICENSE


Usage
-----

Run the following command in a terminal or PowerShell:

python extract_outfoxies_roms.py <path to main_uncompressed> <output directory>

Windows example:

python .\extract_outfoxies_roms.py "C:\path\to\main_uncompressed" "C:\path\to\output"

macOS / Linux example:

python3 ./extract_outfoxies_roms.py "/path/to/main_uncompressed" "/path/to/output"

The output directory is created automatically if it does not exist.


Output files
------------

- outfxiesj.zip: Japanese ROM set containing 23 files
- outfxies.zip: International ROM set containing 23 files
- 25 individual ROM files used by the Japanese and international sets

ROMs shared by both versions are included in both ZIP files. After creating
the archives, the script reads every entry back and verifies its SHA-1 hash.
The script exits with an error if verification fails.


Important notices
-----------------

- Use this script only with data that you lawfully own or have obtained.
- Nintendo Switch package extraction, key acquisition, and DRM bypass features
  are not included.
- ROM data, the game, hactool, keys, and batch files are not included.
- Updated or otherwise different builds of the title may not be supported.


License
-------

Copyright (c) 2026 alhumbra

This software is distributed under the MIT License.
See LICENSE for the full license text.

