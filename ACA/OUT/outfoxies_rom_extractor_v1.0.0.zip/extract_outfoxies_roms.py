#!/usr/bin/env python3
# Copyright (c) 2026 alhumbra
# SPDX-License-Identifier: MIT
"""Extract Japanese and world Outfoxies ROM ZIP sets from main_uncompressed.

Input must be an already-uncompressed NSO0 executable.  This script does not
open an NCA, derive console keys, or handle platform DRM.  It writes
outfxiesj.zip, outfxies.zip, and the 25 distinct loose ROM images.
"""

from __future__ import annotations

import argparse
import hashlib
import struct
import zipfile
from pathlib import Path


MULTIPLIER = 0x001834A9
INCREMENT = 0x3C5F5F25

# region id: (virtual address, byte size, initial PRNG state)
REGIONS = {
    0: (0x0076BB33, 0x00100000, 0x090EA801),
    1: (0x009B09B4, 0x00100000, 0x6C9F5B7C),
    2: (0x00AB09B4, 0x00080000, 0x75BC622D),
    3: (0x00B309B4, 0x00200000, 0x38CD3865),
    4: (0x00D309B4, 0x00200000, 0x21CABA25),
    5: (0x00F309B4, 0x00200000, 0x6FD58061),
    6: (0x011309B4, 0x00600000, 0x3C590F12),
    7: (0x017309B4, 0x00200000, 0x0EC73065),
    8: (0x019309B4, 0x01400000, 0x4C65C064),
}

# C75/M37710 internal ROM is initialized separately from the nine game regions.
C75_REGION = (0x0096C15E, 0x00004000, 0x08807D68)

EXPECTED_SHA1 = {
    "c75.bin": "3103e5a0a2867620309fd4fe478a2be0effbeff8",
    "ou1_mprl.11c": "3f5fe5eea817a23dfe42e76f32912ce94d4c49c9",
    "ou1_mpru.11d": "fdefeebf56464a20e3aaefd88df4eee9f7b5c4f3",
    "ou1dat0.20a": "df243aff1a6fb5bcf4d5d883c5af2374a4aff477",
    "ou1dat1.20b": "d4c2820243b84c3f5cdf7f9e66bb50f53d0efed2",
    "ou1spr0.5b": "2f3b96793816d90011586e0f9f71c58b636b6d4c",
    "ou1voi0.6n": "bde9d45979728f5a2cd8ec89f5f81bf16b694cc2",
    "ou1-scr0.1d": "541bd7e9ba12aff4ec4033bd9c6bb19476acb3c4",
    "ou1shas.12s": "54a32b6394d0e6f51bfd281f8a4bafce6ddf6246",
    "ou1shar.18s": "2d3ec5bc519fad2b755018f83fadfe0cba13c292",
    "ou1-rot0.3d": "432b8451eb9eaa3078134fce1e5e2d58a8b64be3",
    "ou1-rot1.3c": "4a54151fada4dfba7232e53e40623e5697eeb7db",
    "ou1-rot2.3b": "d98489aaa840cbffb21c47609961c1163b0336f3",
    "ou1obj0l.4c": "a05d67842fce92f321d1fdd3bd30aa3427775a0c",
    "ou1obj0u.8c": "07d449e54e9971abeb9cd5bb7b372270fafa8bac",
    "ou1obj1l.4b": "6935ec161a12237d4cec732d42070f381c23b47c",
    "ou1obj1u.8b": "d4780ab1929a3e2c2df464363d6451a2bcecb2a2",
    "ou1obj2l.4a": "3563c5378288da58136f102381373bd6fcaeec21",
    "ou1obj2u.8a": "75ed95bb295780126879d67bba4d0ae1da63c928",
    "ou1obj3l.6c": "3f5376fcd3e15af772df65b8eda4d5ee07ee5664",
    "ou1obj3u.9c": "4863302c45ee16aaf2c36dac07aceaf287959c53",
    "ou1obj4l.6b": "b0f46f4ac357918137031a19c36a56a47b7aefd6",
    "ou1obj4u.9b": "521c6849526fb271e6447f6c4f5bfa081f96b91e",
}

WORLD_PROGRAM_SHA1 = {
    "ou2_mprl.11c": "9733ab087cfde1b8fb5b676d8a2eb5325ebdbb56",
    "ou2_mpru.11d": "cb2e7a4838c2b80057edb83ea63116bccb1394d3",
}

ZIP_ENTRY_ORDER = (
    "c75.bin",
    "ou1-rot0.3d",
    "ou1-rot1.3c",
    "ou1-rot2.3b",
    "ou1-scr0.1d",
    "ou1_mprl.11c",
    "ou1_mpru.11d",
    "ou1dat0.20a",
    "ou1dat1.20b",
    "ou1obj0l.4c",
    "ou1obj0u.8c",
    "ou1obj1l.4b",
    "ou1obj1u.8b",
    "ou1obj2l.4a",
    "ou1obj2u.8a",
    "ou1obj3l.6c",
    "ou1obj3u.9c",
    "ou1obj4l.6b",
    "ou1obj4u.9b",
    "ou1shar.18s",
    "ou1shas.12s",
    "ou1spr0.5b",
    "ou1voi0.6n",
)


def u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def map_vaddr(data: bytes, address: int, size: int) -> int:
    sections = (
        (u32(data, 0x14), u32(data, 0x10), u32(data, 0x18)),
        (u32(data, 0x24), u32(data, 0x20), u32(data, 0x28)),
        (u32(data, 0x34), u32(data, 0x30), u32(data, 0x38)),
    )
    for memory, file_offset, section_size in sections:
        if memory <= address and address + size <= memory + section_size:
            return file_offset + address - memory
    raise ValueError(f"virtual range 0x{address:x}+0x{size:x} is outside the NSO")


def recover(ciphertext: bytes, state: int) -> bytes:
    output = bytearray(len(ciphertext))
    for offset, value in enumerate(ciphertext):
        output[offset] = value ^ ((state >> 11) & 0xFF)
        state = (state * MULTIPLIER + INCREMENT) & 0xFFFFFFFF
    return bytes(output)


def deinterleave_words(data: bytes) -> tuple[bytes, bytes]:
    if len(data) % 4:
        raise ValueError("word-interleaved data length is not divisible by four")
    first = bytearray(len(data) // 2)
    second = bytearray(len(data) // 2)
    first[0::2], first[1::2] = data[0::4], data[1::4]
    second[0::2], second[1::2] = data[2::4], data[3::4]
    return bytes(first), bytes(second)


def swap16(data: bytes) -> bytes:
    output = bytearray(len(data))
    output[0::2], output[1::2] = data[1::2], data[0::2]
    return bytes(output)


def split_program(data: bytes, prefix: str) -> dict[str, bytes]:
    program_u_swapped, program_l_swapped = deinterleave_words(data)
    return {
        f"{prefix}_mpru.11d": swap16(program_u_swapped),
        f"{prefix}_mprl.11c": swap16(program_l_swapped),
    }


def split_roms(regions: dict[int, bytes]) -> dict[str, bytes]:
    roms = {
        "ou1dat0.20a": regions[1][:0x80000],
        "ou1dat1.20b": regions[1][0x80000:],
        "ou1spr0.5b": regions[2],
        "ou1voi0.6n": regions[3],
        "ou1-scr0.1d": regions[4],
        "ou1shas.12s": regions[5],
        "ou1-rot0.3d": regions[6][0x000000:0x200000],
        "ou1-rot1.3c": regions[6][0x200000:0x400000],
        "ou1-rot2.3b": regions[6][0x400000:0x600000],
        "ou1shar.18s": regions[7],
    }
    roms.update(split_program(regions[0], "ou1"))
    for index in range(5):
        start = index * 0x400000
        lower, upper = deinterleave_words(regions[8][start : start + 0x400000])
        lower_socket = ("4c", "4b", "4a", "6c", "6b")[index]
        upper_socket = ("8c", "8b", "8a", "9c", "9b")[index]
        roms[f"ou1obj{index}l.{lower_socket}"] = lower
        roms[f"ou1obj{index}u.{upper_socket}"] = upper
    return roms


def write_verified_zip(
    destination: Path,
    roms: dict[str, bytes],
    expected: dict[str, str],
    entry_order: tuple[str, ...],
) -> None:
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in entry_order:
            info = zipfile.ZipInfo(name, date_time=(1996, 12, 24, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100664 << 16
            archive.writestr(info, roms[name], compresslevel=9)

    with zipfile.ZipFile(destination, "r") as archive:
        if archive.namelist() != list(entry_order):
            raise SystemExit(f"error: unexpected entry order in {destination.name}")
        for name in entry_order:
            digest = hashlib.sha1(archive.read(name)).hexdigest()
            if digest != expected[name]:
                raise SystemExit(f"error: {destination.name}:{name} failed SHA-1 verification")
    print(f"ZIP OK   {destination} ({len(entry_order)} verified entries)")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("main_uncompressed", type=Path)
    parser.add_argument("output_directory", type=Path)
    args = parser.parse_args()

    nso = args.main_uncompressed.read_bytes()
    if nso[:4] != b"NSO0":
        raise SystemExit("error: input is not an NSO0 executable")
    if u32(nso, 0x0C) & 7:
        raise SystemExit("error: NSO sections are still compressed; use main_uncompressed")

    regions: dict[int, bytes] = {}
    for region_id, (address, size, seed) in REGIONS.items():
        file_offset = map_vaddr(nso, address, size)
        ciphertext = nso[file_offset : file_offset + size]
        regions[region_id] = recover(ciphertext, seed)

    roms = split_roms(regions)
    c75_address, c75_size, c75_seed = C75_REGION
    c75_offset = map_vaddr(nso, c75_address, c75_size)
    roms["c75.bin"] = recover(nso[c75_offset : c75_offset + c75_size], c75_seed)
    world_address, world_size, world_seed = 0x0086BB33, 0x00100000, 0x51A35FD1
    world_offset = map_vaddr(nso, world_address, world_size)
    world_region = recover(nso[world_offset : world_offset + world_size], world_seed)
    roms.update(split_program(world_region, "ou2"))
    expected = dict(EXPECTED_SHA1)
    expected.update(WORLD_PROGRAM_SHA1)
    args.output_directory.mkdir(parents=True, exist_ok=True)
    failures = 0
    for name in expected:
        payload = roms[name]
        digest = hashlib.sha1(payload).hexdigest()
        status = "OK" if digest == expected[name] else "MISMATCH"
        failures += status != "OK"
        (args.output_directory / name).write_bytes(payload)
        print(f"{status:8s} {name:18s} size=0x{len(payload):x} sha1={digest}")

    if failures:
        raise SystemExit(f"error: {failures} output hash(es) did not match the analyzed build")

    japanese_roms = {name: roms[name] for name in ZIP_ENTRY_ORDER}
    write_verified_zip(
        args.output_directory / "outfxiesj.zip",
        japanese_roms,
        EXPECTED_SHA1,
        ZIP_ENTRY_ORDER,
    )

    world_entry_order = tuple(
        name.replace("ou1_mpr", "ou2_mpr") if name.startswith("ou1_mpr") else name
        for name in ZIP_ENTRY_ORDER
    )
    world_roms = {name: roms[name] for name in world_entry_order}
    world_expected = {
        name: (WORLD_PROGRAM_SHA1[name] if name in WORLD_PROGRAM_SHA1 else EXPECTED_SHA1[name])
        for name in world_entry_order
    }
    write_verified_zip(
        args.output_directory / "outfxies.zip",
        world_roms,
        world_expected,
        world_entry_order,
    )
    print(f"Successfully wrote {len(roms)} loose ROM images and both verified ZIP sets.")


if __name__ == "__main__":
    main()
