Outfoxies ROM Extractor
=======================

Arcade Archives版『The Outfoxies』の展開済み実行ファイル
main_uncompressed から、日本版・海外版のROM ZIPを作成するPythonスクリプトです。

作者: alhumbra
配布サイト: https://github.com/alhumbra/botuneta_Abandoned-Ideas


必要なもの
----------

- Python 3.9以降
- ユーザー自身が正当に用意した、展開済みの main_uncompressed

本配布物には、hactool、鍵ファイル、main decompile.bat などの
バッチファイルは含まれていません。

スクリプトを使用する前に、ユーザー自身の環境と適法に入手したデータを使って
main_uncompressed を生成してください。

圧縮されたままの main は入力できません。NSOセクションが展開されていない場合、
スクリプトはエラーを表示して終了します。


ファイル構成
------------

extract_outfoxies_roms.py
README_JA.txt
README_EN.txt
LICENSE


使い方
------

ターミナルまたはPowerShellで、次のように実行します。

python extract_outfoxies_roms.py <main_uncompressedのパス> <出力先ディレクトリ>

Windowsでの例:

python .\extract_outfoxies_roms.py "C:\path\to\main_uncompressed" "C:\path\to\output"

macOS / Linuxでの例:

python3 ./extract_outfoxies_roms.py "/path/to/main_uncompressed" "/path/to/output"

出力先ディレクトリが存在しない場合は自動的に作成されます。


出力されるファイル
------------------

- outfxiesj.zip: 日本版ROMセット、23ファイル
- outfxies.zip: 海外版ROMセット、23ファイル
- 日本版・海外版を合わせた25個の個別ROMファイル

日本版と海外版で共通するROMは両方のZIPに収録されます。
ZIP作成後、スクリプトは各ファイルを読み戻してSHA-1を検証します。
不一致が見つかった場合はエラー終了します。


注意事項
--------

- このスクリプトは、ユーザー自身が適法に所有・取得したデータに対して使用してください。
- Nintendo Switchのパッケージ展開、鍵の取得、DRM回避機能は含まれていません。
- ROMデータ、ゲーム本体、hactool、鍵、バッチファイルは含まれていません。
- 対象タイトルの更新版や異なるビルドでは動作しない可能性があります。


ライセンス
----------

Copyright (c) 2026 alhumbra

このソフトウェアはMIT Licenseで提供されます。
ライセンス全文は LICENSE を参照してください。

