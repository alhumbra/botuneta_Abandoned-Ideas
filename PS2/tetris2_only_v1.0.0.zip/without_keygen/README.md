# without_keygen

This standalone script is one variant of Tetris2-only Extractor 1.0.0.
Read the [English user guide](../README.md), [Japanese user guide](../README_JA.md), [legal notices](LEGAL_NOTICE.md), and LICENSE before redistribution.

The script needs no other Python file. Put the supported disc input or required decompressed internal files beside it and double-click, or pass an input path on the command line. The complete source package contains the separate analysis documentation.
