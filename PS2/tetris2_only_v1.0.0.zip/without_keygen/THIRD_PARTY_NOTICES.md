# Third-party notices

Tetris2-only Extractor v1.0.0: GPL-2.0-or-later.
Copyright (C) 2026 Tetris Collection Extractor contributors.
Modified 2026-11-03: tetris2-only outputs, loose internal-file input, and separately generated variants with/without FD1094 recovery.

## LZS2 — both variants

QuickBMS: Copyright 2009-2022 Luigi Auriemma; GPL-2.0-or-later.
LZS2 implementation credits Treeki. Adapted to Python with bounded format checks and CPU checkpoints.

- https://github.com/LittleBigBug/QuickBMS/blob/master/src/quickbms.c
- https://github.com/LittleBigBug/QuickBMS/blob/master/LICENSE
- https://github.com/LittleBigBug/QuickBMS/blob/master/src/included/sega_lzs2.c
- https://github.com/Treeki/RandomStuff/blob/eeb8c19408ac8a6d4adde6f93dc67b7a2843878e/SegaLZS2Decomp.c

## No FD1094 implementation

This variant includes no FD1094 key-generation/decryption implementation, seed, expected key hash or existing-key inclusion. The optional with-key variant is outside this folder.

## Reference metadata and format background

- https://github.com/mamedev/mame/blob/mame0289/src/mame/sega/segas16b.cpp
- https://github.com/mamedev/mame/blob/mame0289/src/mame/sega/sega16sp.cpp
- https://milkchoco.info/archives/6063

The article's text, images, HSP program and Python listings are not included. Tile conversion uses independently arranged lookup tables. No original ROM, complete key payload, emulator or other extractor executable is bundled. MAME is not bundled.

Original project source, original documentation and the original read-only reproduction code are GPL-2.0-or-later. Upstream license texts and adapted components retain their respective notices and terms. No full MAME emulator is incorporated.
