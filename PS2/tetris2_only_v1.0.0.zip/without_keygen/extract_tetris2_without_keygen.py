# SPDX-License-Identifier: GPL-2.0-or-later
# Copyright (C) 2026 Tetris Collection Extractor contributors.
# LZS2 decoder adapted from QuickBMS by Luigi Auriemma and Treeki.
"""Tetris2-only Extractor 1.0.0: offline disc or internal-file conversion.

No complete ROM or key payload is embedded. See README_JA.md and licenses.
"""
from __future__ import annotations


import argparse
import array
import ctypes
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import sys
import tempfile
import time
import zipfile
import zlib

VERSION = '1.0.0'

VARIANT = 'without_keygen'

MAX_PAK_BYTES = 64*1024*1024

MAX_ASSET_BYTES = 4*1024*1024

class ExtractionError(Exception):
    """A validated failure that can be reported without local path disclosure."""

def require(condition, message):
    if not condition:
        raise ExtractionError(message)

class CpuBudget:
    """Cooperative duty limit plus best-effort affinity and low priority."""
    def __init__(self, duty=0.25, cores=1):
        self.duty = duty
        self.cores = cores
        self.settings = {'requested_duty': duty, 'requested_cores': cores,
                         'priority_lowered': False, 'affinity_applied': False}
        if os.name == 'nt':
            k = ctypes.WinDLL('kernel32', use_last_error=True)
            k.GetCurrentProcess.restype = ctypes.c_void_p
            k.SetPriorityClass.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
            k.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
            k.SetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
            handle = k.GetCurrentProcess()
            self.settings['priority_lowered'] = bool(k.SetPriorityClass(handle, 0x40))
            allowed, system = ctypes.c_size_t(), ctypes.c_size_t()
            if k.GetProcessAffinityMask(handle, ctypes.byref(allowed), ctypes.byref(system)):
                bits = [i for i in range(ctypes.sizeof(ctypes.c_size_t)*8) if allowed.value & (1 << i)]
                mask = sum(1 << i for i in bits[:cores])
                self.settings['affinity_applied'] = bool(mask and k.SetProcessAffinityMask(handle, mask))
        else:
            try:
                os.nice(10)
                self.settings['priority_lowered'] = True
            except (AttributeError, OSError):
                pass
            try:
                allowed = sorted(os.sched_getaffinity(0))
                os.sched_setaffinity(0, set(allowed[:cores]))
                self.settings['affinity_applied'] = True
            except (AttributeError, OSError):
                pass
        self.wall = time.monotonic()
        self.cpu = time.process_time()

    def checkpoint(self, force=False):
        used = time.process_time() - self.cpu
        if not force and used < 0.02:
            return
        if self.duty < 1:
            delay = used / self.duty - (time.monotonic() - self.wall)
            if delay > 0:
                time.sleep(delay)
        self.wall, self.cpu = time.monotonic(), time.process_time()

def fingerprints(data):
    return {'bytes': len(data), 'crc32': f'{zlib.crc32(data):08x}',
            'sha1': hashlib.sha1(data).hexdigest(),
            'sha256': hashlib.sha256(data).hexdigest()}

def parse_cue(path):
    raw = path.read_bytes()
    if raw.startswith((b'\xff\xfe', b'\xfe\xff')):
        text = raw.decode('utf-16')
    else:
        for encoding in ('utf-8-sig', 'cp932'):
            try:
                text = raw.decode(encoding)
                break
            except UnicodeDecodeError:
                continue
        else:
            raise ExtractionError('Unsupported CUE encoding; use UTF-8.')
    files = re.findall(r'^\s*FILE\s+(?:"([^"]+)"|(\S+))\s+(\S+)\s*$', text, re.I | re.M)
    require(len(files) == 1 and files[0][2].upper() == 'BINARY',
            'Only a single local BINARY-file CUE is supported.')
    name = files[0][0] or files[0][1]
    # Refuse absolute paths and traversal in an untrusted CUE.
    require(not re.match(r'^(?:[A-Za-z]:|[/\\])', name), 'CUE must use a relative BIN filename.')
    require('..' not in name.replace('\\', '/').split('/'), 'CUE parent traversal is unsupported.')
    image = path.parent / name.replace('\\', '/')
    require(image.is_file(), 'The BIN named by the CUE was not found.')
    tracks = list(re.finditer(r'^\s*TRACK\s+\d+\s+(\S+)\s*$', text, re.I | re.M))
    data_tracks = [t for t in tracks if t.group(1).upper() != 'AUDIO']
    require(len(data_tracks) == 1, 'Exactly one data track is supported.')
    selected = data_tracks[0]
    next_track = next((t.start() for t in tracks if t.start() > selected.start()), len(text))
    body = text[selected.end():next_track]
    index = re.search(r'^\s*INDEX\s+01\s+(\d+):(\d+):(\d+)\s*$', body, re.I | re.M)
    require(index is not None, 'CUE data track is missing INDEX 01.')
    minutes, seconds, frames = map(int, index.groups())
    require(seconds < 60 and frames < 75, 'Invalid CUE timestamp.')
    modes = {'MODE2/2352': (2352, 24), 'MODE1/2352': (2352, 16),
             'MODE1/2048': (2048, 0), 'MODE2/2336': (2336, 8)}
    mode = selected.group(1).upper()
    require(mode in modes, 'Unsupported CUE data-track mode.')
    stride, offset = modes[mode]
    return image, stride, offset, (minutes*60*75 + seconds*75 + frames)*stride

class IsoDisc:
    """Bounded ISO9660 reader over 2048-byte sectors or raw CD sectors."""
    def __init__(self, source, budget):
        self.budget = budget
        self.file = None
        if source.suffix.lower() == '.cue':
            image, self.stride, self.offset, self.base = parse_cue(source)
        else:
            image = source
            self.base = 0
            require(image.is_file(), 'Input image was not found.')
            found = []
            with image.open('rb') as stream:
                for stride, offset in [(2352,24),(2352,16),(2048,0),(2336,8)]:
                    stream.seek(16*stride + offset)
                    if stream.read(7) == b'\x01CD001\x01':
                        found.append((stride, offset))
            require(len(found) == 1, 'Cannot identify an ISO9660 data track; pass its supported CUE.')
            self.stride, self.offset = found[0]
        self.file = image.open('rb')
        try:
            self.total_bytes = image.stat().st_size
            self.sectors = (self.total_bytes - self.base) // self.stride
            pvd = self.sector(16)
            require(pvd[:7] == b'\x01CD001\x01', 'Invalid ISO9660 primary volume descriptor.')
            require(struct.unpack_from('<H', pvd, 128)[0] == 2048, 'Unsupported ISO logical block size.')
            root = self.record(pvd[156:156+pvd[156]])
            require(root[2] & 2, 'Invalid ISO root directory.')
            self.root = root
        except BaseException:
            self.close()
            raise

    def __enter__(self): return self
    def __exit__(self, *_): self.close()
    def close(self):
        if self.file is not None:
            self.file.close()
            self.file = None

    def sector(self, number):
        require(0 <= number < self.sectors, 'ISO sector is outside the input image.')
        self.file.seek(self.base + number*self.stride + self.offset)
        data = self.file.read(2048)
        require(len(data) == 2048, 'Truncated ISO sector.')
        return data

    @staticmethod
    def record(data):
        require(len(data) >= 34 and data[0] <= len(data), 'Malformed ISO directory record.')
        require(33 + data[32] <= data[0], 'Malformed ISO filename.')
        extent, size = struct.unpack_from('<I', data, 2)[0], struct.unpack_from('<I', data, 10)[0]
        require(extent == struct.unpack_from('>I', data, 6)[0] and size == struct.unpack_from('>I', data, 14)[0],
                'ISO directory byte-order fields disagree.')
        require(not (data[25] & 128) and not data[26] and not data[27],
                'Multi-extent or interleaved ISO files are unsupported.')
        return extent, size, data[25], data[33:33+data[32]]

    def extent(self, number, size, limit):
        require(0 <= size <= limit, 'ISO object exceeds the supported size limit.')
        count = (size + 2047)//2048
        require(number >= 0 and number+count <= self.sectors, 'ISO extent is outside the image.')
        output = bytearray()
        for first in range(0, count, 256):
            batch = min(256, count-first)
            if self.stride == 2048:
                self.file.seek(self.base+(number+first)*2048)
                block = self.file.read(batch*2048)
                require(len(block) == batch*2048, 'Truncated ISO file.')
                output.extend(block)
            else:
                self.file.seek(self.base+(number+first)*self.stride)
                block = self.file.read(batch*self.stride)
                require(len(block) == batch*self.stride, 'Truncated raw CD data.')
                for i in range(batch):
                    start = i*self.stride+self.offset
                    output.extend(block[start:start+2048])
            self.budget.checkpoint()
        return bytes(output[:size])

    def entries(self, directory):
        extent, size, _, _ = directory
        data = self.extent(extent, size, 8*1024*1024)
        entries, position = {}, 0
        while position < len(data):
            length = data[position]
            if not length:
                position = (position//2048+1)*2048
                continue
            require(position+length <= len(data) and position//2048 == (position+length-1)//2048,
                    'ISO directory record crosses a sector.')
            item = self.record(data[position:position+length])
            position += length
            if item[3] in (b'\0', b'\1'):
                continue
            try:
                name = item[3].decode('ascii').split(';',1)[0].lower()
            except UnicodeDecodeError:
                raise ExtractionError('Non-ASCII ISO identifiers are unsupported.')
            require(name not in entries, 'Duplicate ISO identifier.')
            entries[name] = item
        return entries

    def read_file(self, name):
        item = self.root
        parts = name.replace('\\','/').lower().split('/')
        require(0 < len(parts) <= 16 and all(p and p not in ('.','..') for p in parts), 'Invalid logical ISO path.')
        for part in parts:
            require(item[2] & 2, 'ISO path component is not a directory.')
            entries = self.entries(item)
            require(part in entries, 'Required disc file is missing: '+part)
            item = entries[part]
        require(not item[2] & 2, 'Expected an ISO file.')
        return self.extent(item[0], item[1], MAX_PAK_BYTES)

def decode_lzs2(data, expected_size, budget):
    """Translate the QuickBMS/Treeki LZS2 format; bounded reads and writes."""
    require(data[:4] == b'lzs2' and len(data) >= 8, 'Missing LZS2 header.')
    size = struct.unpack_from('<I', data, 4)[0]
    require(size == expected_size and 0 < size <= MAX_ASSET_BYTES, 'LZS2 length does not match its PAK entry.')
    ring, output = bytearray(4096), bytearray()
    cursor, ring_position = 8, 0
    next_yield = 16384
    try:
        while len(output) < size:
            control = data[cursor]
            cursor += 1
            for bit in range(7,-1,-1):
                if len(output) == size:
                    break
                if control & (1 << bit):
                    require(cursor+2 <= len(data), 'Truncated LZS2 reference.')
                    token = (data[cursor] << 8) | data[cursor+1]
                    cursor += 2
                    count, source = (token >> 12)+3, token & 4095
                    require(len(output)+count <= size, 'LZS2 reference exceeds declared output.')
                    for _ in range(count):
                        value = ring[source]
                        source = (source+1)&4095
                        output.append(value)
                        ring[ring_position] = value
                        ring_position = (ring_position+1)&4095
                else:
                    value = data[cursor] ^ (ring_position & 255)
                    cursor += 1
                    output.append(value)
                    ring[ring_position] = value
                    ring_position = (ring_position+1)&4095
            if len(output) >= next_yield:
                budget.checkpoint()
                next_yield += 16384
    except IndexError:
        raise ExtractionError('Truncated LZS2 literal/control data.')
    budget.checkpoint()
    return bytes(output)

def read_assets(pak, budget):
    require(pak[:8] == b'PAKFILE\0' and len(pak) >= 16, 'Invalid BIN.PAK header.')
    count = struct.unpack_from('>I', pak, 8)[0]
    require(0 < count <= 10000 and 16+64*count <= len(pak), 'Invalid PAK directory length.')
    entries = {}
    for i in range(count):
        record = pak[16+i*64:80+i*64]
        try:
            name = record[:48].split(b'\0',1)[0].decode('ascii').lower()
        except UnicodeDecodeError:
            raise ExtractionError('Invalid PAK identifier.')
        require(name and '/' not in name and '\\' not in name and name not in entries,
                'Duplicate or unsafe PAK identifier.')
        entries[name] = struct.unpack('>4I', record[48:])
    assets, sources = {}, []
    for name, (expected_size, expected_sha256) in SOURCE_FILES.items():
        require(name in entries, 'Required internal PAK file is missing: '+name)
        flag, packed_size, sector, size = entries[name]
        offset = sector*2048
        require(flag in (0,1) and size == expected_size and offset >= 16+64*count,
                'Unsupported PAK entry: '+name)
        require(packed_size > 0 and offset+packed_size <= len(pak), 'PAK data is outside its container: '+name)
        block = pak[offset:offset+packed_size]
        content = decode_lzs2(block, size, budget) if flag else block
        require(len(content) == expected_size and hashlib.sha256(content).hexdigest() == expected_sha256,
                'Unsupported or modified internal file: '+name)
        assets[name] = content
        sources.append({'name':name, **fingerprints(content)})
    return assets, sources

SOURCE_FILES = {'tetris.obj': (131072,
                'd23647bcfc88ed570a4b7be04fe2cf1eb890f3a51cecf2b058702d67af947f63'),
 'tetris.scr': (262144,
                'b92184c4793b8e30a58d727f5492d1921613e037db1977600903c949356974a2'),
 'tetris.snd': (32768,
                '5f052199e7caeb60ad476781a8d7d72ba49abfd0750ea4b8dbe8657d802def41'),
 'tetrisd.p94': (131072,
                 'd8279cd1b9b94b5918c21b36cb4a7ad49bd0e1061ea59ab1bc6e26bb06ef6306')}

ROM_MANIFEST = {'315-5298.b9': (235, '39b47212', '432b47aee5ecbf08a8a6dc2f8379c816feb86328'),
 'epr-12165.b9': (65536,
                  '62640221',
                  'c311d3847a981d0e1609f9b3d80481565d32d78c'),
 'epr-12166.b10': (65536,
                   '9abd183b',
                   '621b017cb34973f9227be383e26b5cd41aea9422'),
 'epr-12167.b11': (65536,
                   '2495fd4e',
                   '2db94ead9223a67238a97e724668076fc43e5534'),
 'epr-12168.a7': (32768,
                  'bd9ba01b',
                  'fafa7dc36cc057a50ae4cdf7a35f3594292336f4'),
 'epr-12192.a5': (131072,
                  'a1c8af00',
                  'a8e4b289eb3939d6798bb78df1b4ae51c8ccc2d6'),
 'epr-12193.a7': (131072,
                  '44466ed4',
                  'ddb4f0310987e54ce4cd9ffa2813e2d1309aeaaa'),
 'mpr-12194.b1': (65536,
                  '2fb38880',
                  '0e1b601bbda78d1887951c1f7e752531c281bc83'),
 'mpr-12195.b5': (65536,
                  'd6a02cba',
                  'd80000f92e754e89c6ca7b7273feab448fc9a061')}

SPRITE_MANIFEST = {'epr-12169.b1': (32768,
                  'dacc6165',
                  '87b1a7643e3630ff73b2b117752496e1ea5da23d'),
 'epr-12170.b5': (32768,
                  '87354e42',
                  'e7fd55aee59b51d82cb9b619fbb815ad6839560c'),
 'mpr-12194.b1': (65536,
                  '2fb38880',
                  '0e1b601bbda78d1887951c1f7e752531c281bc83'),
 'mpr-12195.b5': (65536,
                  'd6a02cba',
                  'd80000f92e754e89c6ca7b7273feab448fc9a061')}

def verify_blob(name, data, expected):
    size, crc, sha = expected
    require(len(data) == size and f'{zlib.crc32(data):08x}' == crc
            and hashlib.sha1(data).hexdigest() == sha,
            'Output size/CRC32/SHA-1 verification failed: '+name)

def tile_planes(data, budget):
    require(len(data) % 4 == 0, 'Invalid packed tile length.')
    # A packed byte contains two pixels. Generate its contribution to each
    # 1-bit plane, then assemble eight pixels from four bytes.
    tables = [[((value >> (4+p)) & 1)*2 + ((value >> p) & 1)
               for value in range(256)] for p in range(3)]
    result = [bytearray(len(data)//4) for _ in range(3)]
    for index in range(0,len(data),4):
        a,b,c,d = data[index:index+4]
        for plane in range(3):
            table = tables[plane]
            result[plane][index//4] = (table[a]<<6) | (table[b]<<4) | (table[c]<<2) | table[d]
        if index % 8192 == 0:
            budget.checkpoint()
    return tuple(map(bytes,result))

def restore_tetris_sprites(data, budget):
    require(len(data) == 131072, 'Invalid Tetris sprite length.')
    require(data[65536::2] == data[1:65536:2] and not any(data[65537::2]),
            'Unexpected Tetris sprite source-bank relationship.')
    layout = ([(0,8,8)] + [(0x40+i*960,20,48) for i in range(43)]
              + [(0xa180,6,8)] + [(0xa1b0+i*288,16,18) for i in range(2)]
              + [(0xa3f0+i*1368,24,57) for i in range(4)]
              + [(0xb950+i*2304,48,48) for i in range(7)])
    restored = bytearray(data[:65536])
    row_count = 0
    for start,pitch,height in layout:
        skip_left_fill = False
        for row in range(height):
            offset = start+row*pitch
            pixels = [v for value in data[offset:offset+pitch] for v in (value>>4,value&15)]
            visible = [i for i,value in enumerate(pixels) if value]
            first = visible[0] if visible else len(pixels)
            last = visible[-1] if visible else -1
            for i in range(0,len(pixels),4):
                if (i == 0 if skip_left_fill else i < first):
                    require(pixels[i] == 0, 'Sprite restoration would replace a nonzero left pixel.')
                    pixels[i] = 15
                if i+3 > last:
                    require(pixels[i+3] == 0, 'Sprite restoration would replace a nonzero right pixel.')
                    pixels[i+3] = 15
            restored[offset:offset+pitch] = bytes((pixels[i]<<4)|pixels[i+1] for i in range(0,len(pixels),2))
            skip_left_fill = (not skip_left_fill) and not visible
            row_count += 1
        budget.checkpoint()
    restored[0xf850:] = b'\xff'*(65536-0xf850)
    even,odd = bytes(restored[::2]),bytes(restored[1::2])
    files = {'epr-12169.b1':odd, 'epr-12170.b5':even,
             'mpr-12194.b1':odd+b'\xff'*32768, 'mpr-12195.b5':even+odd}
    for name,content in files.items():
        verify_blob(name,content,SPRITE_MANIFEST[name])
    interleaved = bytearray(131072)
    interleaved[::2],interleaved[1::2] = files['mpr-12195.b5'],files['mpr-12194.b1']
    normalize = bytes(((x>>4 if x>>4 != 15 else 0)<<4) | (x&15 if x&15 != 15 else 0) for x in range(256))
    require(bytes(interleaved).translate(normalize) == data,
            'Reconstructed sprites do not normalize back to the complete disc source.')
    return files, {'images':len(layout), 'rows':row_count,
                   'all_four_original_sha1_match':True,
                   'source_normalization_roundtrip_matches':True,
                   'image_crc_patching':False}

def make_pld(mode):
    if mode == 'omit':
        return None
    data = b'\xff'*235
    if mode == 'ff-dummy':
        return data
    # Only the optional PLD placeholder is CRC-adjusted; no image/key is patched.
    base_crc, basis = zlib.crc32(data), {}
    for i in range(32):
        trial = bytearray(data)
        trial[-4+i//8] ^= 1 << (i%8)
        value, mask = zlib.crc32(trial)^base_crc, 1 << i
        while value:
            bit = value.bit_length()-1
            if bit not in basis:
                basis[bit] = (value,mask)
                break
            other,encoded = basis[bit]
            value ^= other
            mask ^= encoded
    value, patch = 0x39b47212^base_crc, 0
    while value:
        other,encoded = basis[value.bit_length()-1]
        value ^= other
        patch ^= encoded
    result = bytearray(data)
    for i in range(4):
        result[-4+i] ^= (patch >> (8*i)) & 255
    require(zlib.crc32(result) == 0x39b47212, 'PLD placeholder CRC generation failed.')
    return bytes(result)

def write_zip(path, files):
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name,data in sorted(files.items()):
            item = zipfile.ZipInfo(name,date_time=(2000,1,1,0,0,0))
            item.compress_type = zipfile.ZIP_DEFLATED
            item.create_system = 3
            item.external_attr = 0o100644 << 16
            archive.writestr(item,data)

def read_loose_assets(folder, budget):
    assets, sources = ({}, [])
    for name, (size, digest) in SOURCE_FILES.items():
        path = folder / name
        require(path.is_file(), 'Required internal file is missing: ' + name)
        require(path.stat().st_size == size, 'Unsupported internal file size: ' + name)
        content = path.read_bytes()
        require(hashlib.sha256(content).hexdigest() == digest, 'Unsupported or modified internal file: ' + name)
        assets[name] = content
        sources.append({'name': name, **fingerprints(content)})
        budget.checkpoint()
    return (assets, sources)

def input_candidates(directory, budget):
    candidates = []
    if all(((directory / name).is_file() for name in SOURCE_FILES)):
        candidates.append(directory)
    referenced = set()
    images = []
    for path in sorted(directory.iterdir(), key=lambda p: p.name.casefold()):
        if not path.is_file() or path.suffix.lower() not in ('.cue', '.bin', '.iso'):
            continue
        try:
            with IsoDisc(path, budget) as disc:
                entry = disc.entries(disc.root).get('bin.pak')
                if entry is None or entry[2] & 2:
                    continue
                require(disc.sector(entry[0])[:8] == b'PAKFILE\x00', 'Not the expected PAK format.')
            images.append(path)
            if path.suffix.lower() == '.cue':
                referenced.add(parse_cue(path)[0].resolve())
        except (ExtractionError, OSError):
            continue
    return candidates + [p for p in images if p.suffix.lower() == '.cue' or p.resolve() not in referenced]

def automatic_input(directory, budget):
    candidates = input_candidates(directory, budget)
    require(candidates, 'No supported input beside this script. Place a CUE/BIN or ISO, or all required internal files there.')
    if len(candidates) == 1:
        return candidates[0]
    print('Multiple inputs. Select a number (Enter cancels):')
    for i, path in enumerate(candidates, 1):
        print('  ' + str(i) + ': ' + ('Internal files in this folder' if path.is_dir() else path.name))
    try:
        choice = input('Input number: ').strip()
    except EOFError:
        choice = ''
    require(choice.isascii() and choice.isdecimal() and (1 <= int(choice) <= len(candidates)), 'No valid input selected. Cancelled.')
    return candidates[int(choice) - 1]

def automatic_output(directory):
    target = directory / 'tetris2_extracted'
    number = 2
    while target.exists() or target.is_symlink():
        target = directory / ('tetris2_extracted_' + str(number))
        number += 1
    return target

def run_mame_audit(executable, root, budget):
    require(executable.is_file(), 'Optional MAME executable was not found.')
    command = [str(executable.resolve()), '-rompath', str(root.resolve()), '-verifyroms', 'tetris2']
    try:
        result = subprocess.run(command, capture_output=True, timeout=120)
    except subprocess.TimeoutExpired:
        raise ExtractionError('MAME ROM audit timed out.')
    text = (result.stdout + result.stderr).decode('utf-8', errors='replace')
    for value in (str(root.resolve()), str(executable.resolve())):
        text = text.replace(value, '<local-path>').replace(value.replace('\\', '/'), '<local-path>')
    (root / 'mame_audit.txt').write_text(text, encoding='utf-8')
    budget.checkpoint()
    return {'exit_code': result.returncode, 'note': 'CRC-oriented audit; a PLD dummy is not an original SHA-1 match. Missing key is reported separately.'}

def extract(source, output, budget, pld_mode='crc-dummy', keep_source=False, mame=None):
    require(not output.exists() and (not output.is_symlink()), 'Output already exists. Nothing was overwritten.')
    if source.is_dir():
        print('[1/4] Reading verified internal files...', flush=True)
        assets, sources = read_loose_assets(source, budget)
        input_format = {'kind': 'internal_files'}
    else:
        print('[1/4] Reading ISO9660 and BIN.PAK...', flush=True)
        with IsoDisc(source, budget) as disc:
            pak = disc.read_file('BIN.PAK')
            input_format = {'kind': 'disc', 'sector_bytes': disc.stride, 'user_offset': disc.offset}
        assets, sources = read_assets(pak, budget)
        del pak
    print('[2/4] Restoring and verifying sprite ROMs...', flush=True)
    sprites, sprite_report = restore_tetris_sprites(assets['tetris.obj'], budget)
    print('[3/4] Building tetris2 ROM files...', flush=True)
    tiles = tile_planes(assets['tetris.scr'], budget)
    files = {'epr-12192.a5': assets['tetrisd.p94'][::2] + b'\xff' * 65536, 'epr-12193.a7': assets['tetrisd.p94'][1::2] + b'\xff' * 65536, 'epr-12165.b9': tiles[0], 'epr-12166.b10': tiles[1], 'epr-12167.b11': tiles[2], 'epr-12168.a7': assets['tetris.snd'], 'mpr-12194.b1': sprites['mpr-12194.b1'], 'mpr-12195.b5': sprites['mpr-12195.b5']}
    key_status = {'status': 'omitted', 'note': 'Key generation and key-file loading are not included. This ZIP alone cannot run the encrypted tetris2 set.'}
    print('      Key-free variant: 317-0092.key is never generated, read, or included.', flush=True)
    for name, content in files.items():
        verify_blob(name, content, ROM_MANIFEST[name])
    pld = make_pld(pld_mode)
    if pld is not None:
        files['315-5298.b9'] = pld
    required = set(ROM_MANIFEST) - {'315-5298.b9'}
    if key_status['status'] == 'omitted':
        required.discard('317-0092.key')
    require(set(files) == required | ({'315-5298.b9'} if pld is not None else set()), 'Unexpected output members.')
    report = {'tool': 'Tetris2-only Extractor', 'version': VERSION, 'variant': VARIANT, 'input_format': input_format, 'source_files': sources, 'cpu': budget.settings, 'key': key_status, 'sprite_reconstruction': sprite_report, 'pld': {'mode': pld_mode, 'is_original_dump': False}, 'files': [{'name': name, **fingerprints(data)} for name, data in sorted(files.items())]}
    print('[4/4] Publishing verified tetris2.zip...', flush=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.tetris2-', dir=output.parent) as temp:
        root = Path(temp)
        write_zip(root / 'tetris2.zip', files)
        if keep_source:
            (root / 'source').mkdir()
            for name, data in assets.items():
                (root / 'source' / name).write_bytes(data)
        if mame is not None:
            report['mame_audit'] = run_mame_audit(mame, root, budget)
        (root / 'verification.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
        require(not output.exists() and (not output.is_symlink()), 'Output appeared during processing; refusing overwrite.')
        root.rename(output)
    budget.checkpoint(force=True)
    print('Complete: tetris2.zip (' + str(len(files)) + ' members). Key: ' + key_status['status'], flush=True)
    print('Output folder: ' + output.name, flush=True)
    return report

def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('input', nargs='?', type=Path, help='CUE/BIN/ISO or internal-file folder; omitted: detect beside this script')
    parser.add_argument('-o', '--output', type=Path, help='New output folder; existing paths are refused')
    parser.add_argument('--version', action='version', version=VERSION)
    parser.add_argument('--cpu-duty', type=float, default=0.25, help='Cooperative CPU-time fraction, 0.05..1.0')
    parser.add_argument('--cores', type=int, default=1, help='Best-effort affinity limit')
    parser.add_argument('--pld-mode', choices=('crc-dummy', 'ff-dummy', 'omit'), default='crc-dummy')
    parser.add_argument('--keep-source', action='store_true')
    parser.add_argument('--mame', type=Path, help='Optional installed MAME for tetris2 audit only')
    args = parser.parse_args(argv)
    if not 0.05 <= args.cpu_duty <= 1 or not 1 <= args.cores <= (os.cpu_count() or 1):
        parser.error('CPU duty must be 0.05..1.0; cores must be within the local CPU count.')
    try:
        budget = CpuBudget(args.cpu_duty, args.cores)
        if args.input is None:
            directory = Path(__file__).resolve().parent
            args.input = automatic_input(directory, budget)
            if args.output is None:
                args.output = automatic_output(directory)
        if args.output is None:
            args.output = Path('tetris2_extracted')
        extract(args.input, args.output, budget, args.pld_mode, args.keep_source, args.mame)
    except KeyboardInterrupt:
        print('Cancelled. No incomplete final output was published.', file=sys.stderr)
        return 130
    except ExtractionError as error:
        print('Error: ' + str(error), file=sys.stderr)
        return 1
    except OSError as error:
        print('Operating-system error: ' + (error.strerror or 'file/process operation failed'), file=sys.stderr)
        return 1
    return 0
if __name__ == '__main__':
    result = 1
    try:
        result = main()
    finally:
        if len(sys.argv) == 1 and sys.stdin.isatty():
            try:
                input('Press Enter to close...')
            except (EOFError, KeyboardInterrupt):
                pass
    raise SystemExit(result)
