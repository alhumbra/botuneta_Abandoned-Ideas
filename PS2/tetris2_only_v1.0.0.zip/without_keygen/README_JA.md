# without_keygen — 初回公開版v1.0.0

[日本語の使い方](../README_JA.md) / [English](../README.md) / [注意事項](LEGAL_NOTICE.md)

このPYは単独で動作し、他のPYは必要ありません。対応するディスク入力または必要な内部ファイルを同じフォルダに置いてダブルクリックしてください。
使い方・必要ファイルの一覧は上記の通常README、解析資料は配布全体のdocs/analysisに分けています。
再配布時はLICENSEとTHIRD_PARTY_NOTICES.mdも保持してください。
