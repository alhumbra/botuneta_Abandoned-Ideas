# Third-party notices

Tetris2-only Extractor v1.0.0: GPL-2.0-or-later.
Copyright (C) 2026 Tetris Collection Extractor contributors.
Modified 2026-11-03: tetris2-only outputs, loose internal-file input, and separately generated variants with/without FD1094 recovery.

## LZS2 — both variants

QuickBMS: Copyright 2009-2022 Luigi Auriemma; GPL-2.0-or-later.
LZS2 implementation credits Treeki. Adapted to Python with bounded format checks and CPU checkpoints.

- https://github.com/LittleBigBug/QuickBMS/blob/master/src/quickbms.c
- https://github.com/LittleBigBug/QuickBMS/blob/master/LICENSE
- https://github.com/LittleBigBug/QuickBMS/blob/master/src/included/sega_lzs2.c
- https://github.com/Treeki/RandomStuff/blob/eeb8c19408ac8a6d4adde6f93dc67b7a2843878e/SegaLZS2Decomp.c

## FD1094 — with_keygen only

Copyright Nicola Salmoria, Andreas Naive, Charles MacDonald.
BSD-3-Clause; full conditions/disclaimer in LICENSES/BSD-3-Clause.txt and with_keygen/LICENSES/BSD-3-Clause.txt.
The Python port adapts MAME masked-opcode definitions and word decryption with runtime-generated lookup tables, disc-cache constraints, public generation parameters, and CPU checkpoints.
The without_keygen script does not include this implementation, generation seeds, or expected key hashes.

- https://github.com/mamedev/mame/blob/mame0289/src/mame/sega/fd1094.cpp

## Reference metadata and format background

- https://github.com/mamedev/mame/blob/mame0289/src/mame/sega/segas16b.cpp
- https://github.com/mamedev/mame/blob/mame0289/src/mame/sega/sega16sp.cpp
- https://milkchoco.info/archives/6063

The article's text, images, HSP program and Python listings are not included. Tile conversion uses independently arranged lookup tables. No original ROM, complete key payload, emulator or other extractor executable is bundled. MAME is not bundled.

Original project source, original documentation and the original read-only reproduction code are GPL-2.0-or-later. Upstream license texts and adapted components retain their respective notices and terms. No full MAME emulator is incorporated.
