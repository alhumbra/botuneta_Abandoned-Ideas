# Legal and usage notices / 利用・配布に関する注意

## English

This is an unofficial source-code distribution for one verified data profile. It contains no game ROM, complete key payload, disc image, emulator binary or opaque game-data patch. Neither the tool nor these notices grant permission to reproduce, distribute or use copyrighted game data.

The with_keygen variant reconstructs an FD1094 key using disc-resident encrypted program/cached decrypted data and public MAME algorithms and parameters. It includes candidate word-decryption during reconstruction. The without_keygen variant contains no such generation/decryption implementation and neither reads nor includes existing key files. Its encrypted tetris2 ZIP requires the matching key separately for execution.

These technical distinctions do not determine legality. Applicable copyright, technical-protection/anti-circumvention and other rules may regulate extraction, key recovery, decryption, use and distribution of tools. Requirements and exceptions vary by jurisdiction and circumstances. Owning media, obtaining data locally, publishing source only, charging no fee or stating a research purpose does not by itself establish authorization. No worldwide legal clearance or legal opinion is provided. Obtain appropriate permission or qualified advice where needed; do not use or distribute the tool in violation of applicable law.

GNU GPL and retained third-party licenses govern code permissions and obligations, not rights in game content. Preserve all applicable copyright, license, disclaimer and attribution notices when redistributing. If you distribute modified code, comply with the GPL's applicable notice/source requirements. These notices supplement rather than replace the included licenses.

To the extent allowed by law, the software is provided without warranty under the included license terms. Output hashes identify the supported profile; they do not guarantee compatibility with every emulator, every play session or an original physical PLD. The default PLD is a synthetic placeholder and is labelled as such.

Product and project names identify their respective owners. No affiliation, approval or endorsement is implied. Keep generated game files, keys, disc images and private test artifacts out of source redistributions. Before sharing runtime reports or optional emulator logs, inspect them for local/private information.

## 日本語

本配布は非公式のソースコード配布です。ゲームROM、完成した鍵データ、ディスク画像、エミュレーター実行ファイル、ゲーム差分パッチは同梱しません。この事実は、ツールの公開・利用の適法性を認定するものではありません。

鍵生成あり版は、ディスク内の暗号化プログラムと復号済み命令キャッシュ、MAMEの公開アルゴリズムと生成パラメータを利用します。候補鍵での部分的な復号・照合を含みます。鍵生成なし版は、その生成・復号処理を含めず、既存鍵の読み込み・同梱もしません。

ディスク所有、ローカルでの生成、無料、ソースのみ、研究目的という条件だけで、権利者の許諾や法令上の要件を満たすとは限りません。抽出・鍵復元・復号・利用・ツール提供は、適用法・許諾・具体的事情に応じて別途確認してください。本書は法律意見ではなく、世界各国での適法性を保証しません。

コードのライセンスはゲームデータや技術的保護手段の回避への権利を与えません。再配布時は適用される著作権・ライセンス・出典・免責表示を保持し、変更時はGPLの関連条件に従ってください。適用法が許す範囲で無保証です。権利者の承認・後援はありません。

検証対象は固定の内部データ版です。PLDダミー、全エミュレーターでの動作、全プレイ状況を保証するものではありません。生成ROM・鍵・ディスク画像・私的な検証ファイルをソース配布に追加せず、実行ログ共有前は個人情報を確認してください。
