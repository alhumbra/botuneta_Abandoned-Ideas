# Changelog

## 1.0.0 — 2026-11-03

Initial public release of the Tetris2-only package.

- Two standalone Python scripts: with FD1094 recovery and without any key generation/decryption or existing-key inclusion.
- tetris2.zip only; disc-image and verified loose-file inputs.
- No-argument sibling-input detection, unique output folders and interactive completion pause.
- Default cooperative CPU limiting and explicit PLD placeholder policies.
- English/Japanese user documentation, legal notices, complete code licenses and retained upstream attribution.
- Separate sprite-analysis documentation and read-only reproduction code with disc-table and intact-image evidence.

The earlier multi-game extractor is an implementation antecedent, not an earlier public release of this dedicated package.
