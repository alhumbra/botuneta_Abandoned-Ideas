# Tetris2-only Extractor

**Version 1.0.0 — initial public release, 2026-11-03.**

[日本語](README_JA.md) | [Sprite analysis](docs/analysis/README.md) | [License](LICENSE) | [Third-party notices](THIRD_PARTY_NOTICES.md) | [Legal and usage notices](LEGAL_NOTICE.md)

Offline Python tools that create only the encrypted Sega System 16B **tetris2.zip** from the verified internal-asset revision of PS2 SEGA AGES 2500 Vol.28 Tetris Collection (SLPM-62746). No ROM, complete key file, executable, compressed game payload or binary image patch is bundled or downloaded.

## Choose one script

| Folder / script | Key behavior |
|---|---|
| with_keygen/extract_tetris2_with_keygen.py | Reconstructs 317-0092.key from disc program/cache data and public MAME parameters; includes the resulting key in the ZIP |
| without_keygen/extract_tetris2_without_keygen.py | Contains no FD1094 recovery/decryption implementation, generation seed or expected key hash; never reads or includes an existing key |

A complete key is not present as a standalone file on the disc and is not embedded in either script. The keyless ZIP alone cannot run the encrypted tetris2 set. It is not the decrypted tetris2d set. Both scripts are standalone; neither needs the other or the original multi-game extractor.

## Requirements and double-click launch

Python 3.10+ with standard libraries only. Windows/Python 3.13 was tested. Extract the package before use. With .py associated with the Python console interpreter, place one of the following beside the chosen script and double-click it:

- A single-file CUE/BIN pair, supported raw BIN, or ISO9660 ISO.
- The decompressed internal files listed below, directly in the script's folder.

| Internal file | With key generation | Without key generation |
|---|---|---|
| tetrisd.p94 | Required | Required |
| tetris.obj | Required | Required |
| tetris.scr | Required | Required |
| tetris.snd | Required | Required |
| tetrisi.p94 | Required | Not read |

Internal-file inputs need no disc image, BIN.PAK or emulator. Other games' files are not required. Subfolders are not searched. Inputs must match the known internal-file size/SHA-256 profile. Whole-disc CRC/SHA is not used.

Without arguments, the script scans its own folder, deduplicates a valid CUE and its BIN, and asks for a number if several sources are present. Output goes beside the script into tetris2_extracted, or an unused numbered folder. Existing output is preserved. An interactive no-argument launch waits for Enter before closing, including on errors. Explorer mouse activation itself was not automated in testing.

## Command line

```sh
python extract_tetris2_with_keygen.py "Disc.cue" --output extracted_with_key
python extract_tetris2_without_keygen.py "Disc.iso" --output extracted_no_key
python extract_tetris2_without_keygen.py "source_files" --output extracted_from_files
```

With explicit input and no --output, output defaults to tetris2_extracted in the working directory and refuses an existing path. In no-argument mode it uses the script directory and a unique suffix.

Supported physical layouts: MODE2/2352, MODE1/2352, MODE1/2048 and MODE2/2336. Raw/2048-sector ISO content is detected independently of .bin/.iso extension. Pregap images should be supplied through CUE. Multi-BIN CUEs, ZIP-compressed images, multi-extent ISO files and unknown asset revisions are unsupported.

## How the complete tetris2 set is generated

This section describes the complete build, not just sprite restoration. The descriptions follow the original extractor's format explanations and the two dedicated scripts' actual implementation. All game files are produced at run time; none is embedded in the Python source.

### 1. Read and identify the required internal files

For a disc image, read the ISO9660 directory, locate BIN.PAK, parse its directory, and extract only the four or five required internal files. Expand an LZS2-compressed entry with the bounded decoder. With a loose-file folder, read the already decompressed internal files directly instead. Both routes verify each required file's size and SHA-256 before conversion. Whole-image/whole-PAK hashes and unrelated game assets are not requirements. Container management information is still read, and the implementation reads BIN.PAK into memory when using a disc image.

```text
CUE/BIN or ISO -> ISO9660 -> BIN.PAK -> decompress selected entries
                                              |
Already decompressed internal files ----------+-> verified inputs
                                                     |
                      +------------------------------+-------------------+
                      |               |              |                   |
                 tetrisd.p94     tetris.scr      tetris.obj          tetris.snd
                      |               |              |                   |
                program lanes    tile planes    sprite repair        unchanged
                      |               |              |                   |
                      +---------------+--------------+-------------------+
                                      |
                  optional generated key + selected PLD policy
                                      |
                         validate -> tetris2.zip + report
```

The key-generation variant additionally uses tetrisi.p94. The keyless variant never reads that file or any .key file.

### 2. Assemble the encrypted program ROMs

tetrisd.p94 is 131,072 bytes. Split it by zero-based byte position into two 65,536-byte lanes; append 65,536 bytes of FF to each lane:

```text
epr-12192.a5 = tetrisd.p94[0::2] + 65,536 bytes of FF
epr-12193.a7 = tetrisd.p94[1::2] + 65,536 bytes of FF
```

Each final program ROM is 131,072 bytes. These remain encrypted program ROMs, not decrypted bootleg-format program ROMs. Program extraction itself does not decrypt them; the with-key recovery stage separately tests candidate word decryption against disc caches.

### 3. Convert the tile graphics into three bitplanes

tetris.scr is 262,144 bytes. Read four bytes as eight packed four-bit pixels. For each group, collect bit 0, bit 1 and bit 2 of those pixels into one byte per bitplane, retaining pixel order. The three 65,536-byte plane outputs become epr-12165.b9, epr-12166.b10 and epr-12167.b11, respectively. This is a packing/bitplane conversion, separate from the lost-F sprite repair.

### 4. Restore and assemble the sprite graphics

For the supported 131,072-byte tetris.obj, check the front/back bank relationship, restore the first 64 KiB using the validated 58-image layout and per-image marker state rule, and restore FF padding from 0xF850 to the end of that first bank. Let A be its odd-position bytes and B its even-position bytes; each is 32 KiB:

```text
mpr-12194.b1 = A + 32 KiB of FF
mpr-12195.b5 = B + A
```

Both outputs are 65,536 bytes. The code also verifies two related 32 KiB intermediate ROM hashes in memory, but does not output those files. The full source-normalization round trip and reference hashes must pass. See the separate [sprite analysis](docs/analysis/README.md) for disc-table evidence, empirical blank-row rules and limits; the runtime extractor uses the validated fixed layout.

### 5. Preserve the sound program

Copy the 32,768-byte tetris.snd unchanged as epr-12168.a7. This step neither resamples audio nor modifies sound-program bytes.

### 6. Apply the chosen script's key behavior

- **With key generation:** use tetrisd.p94, the six decrypted instruction-state caches in tetrisi.p94, and public MAME FD1094 algorithms/generation parameters. Infer and test key parameters, generate the 8,192-byte 317-0092.key and require its reference size, CRC32 and SHA-1. Include that generated file in tetris2.zip. No complete input key is embedded or fetched.
- **Without key generation:** perform none of the above. No generation/decryption code or existing-key loading is included. Omit 317-0092.key even if one is present beside the script. The resulting encrypted set is incomplete for standalone execution until the matching key is made available separately to the emulator.

### 7. Apply the PLD policy

The disc inputs do not supply the original PLD dump. By default, generate a 235-byte synthetic 315-5298.b9 placeholder and adjust only that dummy's CRC32 to 39B47212. Its SHA-1 remains different from the original. Alternatively use --pld-mode ff-dummy or --pld-mode omit. This CRC adjustment is not used on program, tile, sprite, sound or key data.

### 8. Validate and publish the final ZIP

Check the reference size, CRC32 and SHA-1 of every real output member. Validate PLD generation according to its explicitly synthetic policy. Write the selected members to a temporary tetris2.zip with deterministic member names and timestamps. Write verification.json, optional selected source files, and optional MAME audit results; then rename the temporary output folder to the final destination after checking that the destination does not exist. The MAME audit is optional and records its own status separately; its failure is not a substitute for the extractor's file checks.

| Final ZIP member | Bytes | Source / operation |
|---|---:|---|
| epr-12192.a5 | 131072 | Program even lane + FF padding |
| epr-12193.a7 | 131072 | Program odd lane + FF padding |
| epr-12165.b9 | 65536 | Tile plane 0 |
| epr-12166.b10 | 65536 | Tile plane 1 |
| epr-12167.b11 | 65536 | Tile plane 2 |
| mpr-12194.b1 | 65536 | Restored sprite A + FF padding |
| mpr-12195.b5 | 65536 | Restored sprite B + A |
| epr-12168.a7 | 32768 | Unchanged sound program |
| 317-0092.key | 8192 | With-key-generation variant only |
| 315-5298.b9 | 235 | Selected PLD placeholder; omitted if requested |

With the default PLD policy, this yields 10 members in the with-key ZIP and 9 in the keyless ZIP. Omitting the PLD reduces either count by one. The ZIP contains only the tetris2 set; the report and optional logs/source files are outside that ZIP in the output folder.

## Outputs and options

The final folder contains tetris2.zip and verification.json. Default ZIP membership is 10 files with key generation, 9 without. The scripts output no other arcade/console game and no separate key/sprite-ROM files. Optional --keep-source also stores only that variant's four or five required internal files.

The default 235-byte PLD placeholder 315-5298.b9 has CRC32 39B47212 but not the original SHA-1. Runtime audit warnings may remain. --pld-mode ff-dummy uses an all-FF dummy; --pld-mode omit leaves it out. Only the PLD dummy receives CRC adjustment. Sprite/program/key outputs receive no CRC patching.

Default --cpu-duty 0.25 and --cores 1 apply cooperative CPU limiting, best-effort one-core affinity and low priority. Instantaneous use is not a hard-capped percentage. --mame PATH optionally runs the installed emulator's ROM audit for tetris2 only; no download or gameplay launch occurs. Audit status is reported separately; the keyless set can fail audit for its missing key.

Reports contain logical input names and fingerprints, not account names or absolute input paths. The optional emulator log replaces known temporary/output and executable paths, but arbitrary third-party emulator text cannot be guaranteed free of all personal information; review generated logs before sharing. Generated ROM/key outputs are not part of this source distribution.

## Validation and analysis

The with-key output matched every member of the previously verified exact tetris2 set, with MAME 0.289 ROM audit passing. The final keyless script was exercised both without arguments using sibling internal files and on a repacked ISO; all nine output members matched the verified set excluding the key. A deliberately invalid sibling key was ignored. Key-generation/decryption code, seeds, key hashes and cache input were checked absent from the keyless variant. Existing-output protection and changed-input rejection were checked.

Analysis is separate from this user guide: [English overview](docs/analysis/README.md), [Japanese overview](docs/analysis/README_JA.md), [reproduction code](docs/analysis/REPRODUCE.md). It distinguishes direct disc observations, empirical marker rules, MAME hash validation and unknown converter internals. The deeper analysis uses Flash Point files as controls; normal Tetris-only extraction does not need them.

## License and responsibilities

Original project source and documentation are GPL-2.0-or-later. The full GNU GPL version 2 is included in LICENSE; source notices permit later versions. The with-key FD1094 adaptation retains its BSD-3-Clause notices and license. LZS2 attribution and source links are retained in THIRD_PARTY_NOTICES.md.

There is no warranty, to the extent permitted by applicable law. Code licenses do not license game content or authorize bypassing technical protections. Possession of a disc, local reconstruction, free distribution, research wording or MAME provenance is not by itself legal clearance. The legality of key recovery, decryption, extraction, use and tool distribution depends on applicable law and authorization. This package does not establish that those uses are lawful worldwide. Read LEGAL_NOTICE.md before redistribution.

No affiliation or endorsement by SEGA, M2, The Tetris Company, MAME or FBNeo is implied. No ROM/key files are included. Do not add generated game content, private logs or disc images when redistributing the source package.
