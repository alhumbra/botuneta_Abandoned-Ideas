# Sprite restoration analysis — initial release 1.0.0

[User README](../../README.md) | [Japanese analysis](README_JA.md)

## Claim and scope

For the fingerprinted SLPM-62746 internal-asset revision, disc-resident data plus public MAME information reproduce the four sprite-ROM sizes, CRC32s and SHA-1s recorded in MAME. No external original ROM, image patch, reference picture or complete key is an input to the reproduction code. Hash agreement is the conventional ROM-identification evidence; it is not an independent hardware redump or a mathematical uniqueness proof.

This initial release includes evidence added on 2026-11-03. New checks are distinguished from surviving historical records.

## Observations, model and validation

| Item | Evidence | Classification |
|---|---|---|
| All 58 Tetris image starts, widths, heights and areas | Table directly read from tetrisd.p94 | Disc observation |
| Shared 576-byte sprite region | Flash Point with F normalized to 0 equals Tetris | Direct disc comparison |
| Pitch, address progression, transparent values and line termination | MAME 0.289 System 16B renderer | Public external source |
| Edge-marker and blank-row rules | Restore deliberately normalized intact Flash Point images | Empirical model, directly tested |
| Per-image state reset | Carrying state across images fails one intact row | Disc-based candidate comparison |
| Tetris padding, bank composition and full result | Reference hashes and normalization round trip | Candidate selection and final check |
| Original porting-tool implementation and intent | Corresponding converter code not identified | Unknown |

## Reconstruction

The source maps F nibbles to 0, while retaining values 1 through E. This is many-to-one: original 0 and F cannot be distinguished from a single source value.

Read image records at file offset 0x5FB0 in tetrisd.p94, stepping eight bytes. Read a little-endian 32-bit shape location and a little-endian 16-bit sprite start. At the shape location, read one-byte width, one-byte height and a little-endian 16-bit area. All areas equal width times height. Stop before a new six-byte record would overlap the earliest shape descriptor. This yields 58 images and 2,680 rows matching the released fixed layout. The production scripts retain that validated fixed layout; the reproduction code reads and checks it from disc.

For each row, find the first and last nonzero nibble. For each four-nibble group, normally restore F at its first nibble if that position precedes the first nonzero pixel, and at its last nibble if it follows the last nonzero pixel. Never replace a nonzero pixel. An all-blank row in the normal state restricts left-marker filling on the next row to its first group; after that restricted row the state returns to normal. Reset state at every image.

Fill the first 64 KiB tail from 0xF850 with FF. Let A be odd-position bytes and B even-position bytes. Construct epr-12169.b1=A, epr-12170.b5=B, mpr-12194.b1=A+32KiB of FF, and mpr-12195.b5=B+A. Only the two MPR files belong in the generated tetris2.zip. The smaller outputs are additional correlated checks, not independent restoration experiments.

## Stronger blank-row check

Read 69 contiguous image layouts from flashpd.p94 starting at 0xA0C0 using the same field interpretation; the first shape descriptor is at 0xA2EA. Their image data covers [0,0xA7E6) in flashp.obj and 1,967 rows.

Normalize F to 0 in these intact disc images, apply the Tetris marker model, then compare the reconstructed bytes against the intact bytes. Intact bytes are used only for comparison, never to choose replacement locations or values.

| Candidate | Entire images matched | Rows matched |
|---|---:|---:|
| No state | 44/69 | 1,890/1,967 |
| State carried across images | 68/69 | 1,966/1,967 |
| State reset per image | 69/69 | 1,967/1,967 |

The final candidate matches all 141 blank rows and all 133 within-image rows following a blank row. These categories overlap. This uses byte comparison, not output-ROM hashes. Two shared images also helped formulate the model, so the whole sample is not claimed to be a fully independent blind test.

One boundary example: image 1's final row at 0x09F0 is blank after normalization. Image 2 starts at 0x0A30 and has its first nonzero nibble at 53. Its intact row has 14 left markers, at 0,4,...,52. Carrying the state across the boundary produces only one; resetting produces all 14.

MAME explains how F terminates reading, but does not enforce this blank-row restoration state. For a normal-direction blank row starting with F00F, later groups are not read; different later F placements may render identically. Rendering alone therefore cannot recover the exact original bytes.

## Results

| File | Bytes | CRC32 | SHA-1 |
|---|---:|---|---|
| epr-12169.b1 | 32768 | dacc6165 | 87b1a7643e3630ff73b2b117752496e1ea5da23d |
| epr-12170.b5 | 32768 | 87354e42 | e7fd55aee59b51d82cb9b619fbb815ad6839560c |
| mpr-12194.b1 | 65536 | 2fb38880 | 0e1b601bbda78d1887951c1f7e752531c281bc83 |
| mpr-12195.b5 | 65536 | d6a02cba | d80000f92e754e89c6ca7b7273feab448fc9a061 |

The first-bank Tetris graphics region changes 25,969 nibbles, all 0 to F. Reinterleaving the MPR files and normalizing F to 0 reproduces the entire tetris.obj. This round trip establishes consistency, not uniqueness; incorrect F placements could also normalize to zero. Original hashes were used during candidate evaluation as well as final checking.

## Reproduce and inspect

[English reproduction guide and code](REPRODUCE.md) uses Python standard libraries and four disc files only: tetris.obj, tetrisd.p94, flashp.obj and flashpd.p94. It writes no ROM and generates no key. These analysis-only Flash Point inputs are not requirements for the production Tetris-only extractor.

Detailed Japanese records: [evidence](EVIDENCE_JA.md), [blank-row comparison](README_BLANK_ROWS.md), [reproduction](README_REPRODUCE.md).

Surviving runtime descriptors covered only 29 of the 58 layouts. The other 29 are now confirmed by the disc table; that is new evidence, not a reconstruction of all historical actions. The original converter implementation and intent remain unknown. This is a tested model for one revision, not a general inverse of a lossy transformation or legal clearance.

## Sources

- https://github.com/mamedev/mame/blob/mame0289/src/mame/sega/segas16b.cpp
- https://github.com/mamedev/mame/blob/mame0289/src/mame/sega/sega16sp.cpp
- https://milkchoco.info/archives/6063
