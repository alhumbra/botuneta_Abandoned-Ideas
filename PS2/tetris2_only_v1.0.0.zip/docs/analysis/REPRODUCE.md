# Reproducing the sprite checks

[Analysis](README.md) | [Japanese instructions](README_REPRODUCE.md)

Use Python 3.10 or later without -O: the code uses assertions. No packages, MAME binary, key, original reference ROM or network access are required. Extract and decompress your own disc's BIN.PAK entries into one folder:

```text
source/
  tetris.obj
  tetrisd.p94
  flashp.obj
  flashpd.p94
```

The program checks their sizes and SHA-256s. Save the code below as check_sprites.py and run:

```sh
python -B check_sprites.py source
```

It reads input files, reconstructs in memory and prints evidence. It never writes game ROMs or keys, and never recovers a key. Standard output can be saved if desired. It uses one processing thread and cooperative sleeps targeting approximately 25% CPU-time duty, not an instantaneous utilization cap. No original image bytes or binary patches are embedded; constants are table locations, model parameters and reference fingerprints.

Expected: 58 Tetris layouts read from disc; matching normalized shared 576 bytes; Tetris candidate lane CRCs 246b9ed7, 4f2a65ea, 87354e42; all four final ROM fingerprints match; full normalization round trip passes. The Flash Point check reports 69 images and 1,967 rows, with 1,890 / 1,966 / 1,967 rows matched for no-state / global-state / per-image-state. The final model matches all 141 blank rows and 133 within-image rows following blank rows. The final line starts with PASS.

Keep any failure as a failure; changing expected fingerprints does not reproduce the documented experiment. Table discovery locations are known profile parameters, not automatically discovered for unknown revisions. This code was extracted from the published README and executed against the verified disc files on 2026-11-03.

The code below is GPL-2.0-or-later, like the project's original source; see ../../LICENSE. No decryption implementation is included.

```python
"""Read-only reproduction; no ROM output, key recovery, or network access."""
from pathlib import Path
import hashlib
import sys
import time
import zlib
import struct

if len(sys.argv) != 2:
    raise SystemExit('Usage: python -B check_sprites.py SOURCE_FOLDER')
folder = Path(sys.argv[1])
s = (folder/'tetris.obj').read_bytes()
f = (folder/'flashp.obj').read_bytes()
d = (folder/'tetrisd.p94').read_bytes()
assert len(d) == 131072
assert hashlib.sha256(d).hexdigest() == 'd8279cd1b9b94b5918c21b36cb4a7ad49bd0e1061ea59ab1bc6e26bb06ef6306'
assert len(s) == len(f) == 131072
assert hashlib.sha256(s).hexdigest() == 'd23647bcfc88ed570a4b7be04fe2cf1eb890f3a51cecf2b058702d67af947f63'
assert hashlib.sha256(f).hexdigest() == '8d0aed6f04b8d356c61961fdfbed0bbc1f22a15d3ecaf7239ed5e982701298c9'
assert all((x >> 4) != 15 and (x & 15) != 15 for x in s)
assert s[65536::2] == s[1:65536:2] and not any(s[65537::2])
norm = bytes(((x >> 4 if x >> 4 != 15 else 0) << 4) |
             (x & 15 if x & 15 != 15 else 0) for x in range(256))
assert s[0xa1b0:0xa3f0] == f[0x3230:0x3470].translate(norm)
print('Shared 576 bytes: normalized match')
for row in (0,1):
    off = 0x3350 + row*16
    print('Second shared image, row',row, f[off:off+16].hex())
reference_layout = ([(0,8,8)] + [(0x40+i*960,20,48) for i in range(43)]
          + [(0xa180,6,8)] + [(0xa1b0+i*288,16,18) for i in range(2)]
          + [(0xa3f0+i*1368,24,57) for i in range(4)]
          + [(0xb950+i*2304,48,48) for i in range(7)])
# Read the numeric profile from the disc file, not from reference_layout.
layout,records = [],[]
pos,first_shape = 0x5fb0,len(d)
while pos+6 <= first_shape:
    shape,start = struct.unpack_from('<IH',d,pos)
    assert pos+6 <= shape <= len(d)-4
    first_shape = min(first_shape,shape)
    width,height,area = struct.unpack_from('<BBH',d,shape)
    assert width and height and area == width*height
    layout.append((start,width,height))
    records.append((pos,shape,start,width,height,area))
    pos += 8
assert first_shape == 0x617e and records[-1][0]+6 == first_shape
assert layout == reference_layout
print('Disc table: all 58 image layouts match, independently of output ROM hashes')
for index in (0,5,44,57):
    pos,shape,start,width,height,area = records[index]
    print('Image',index,'entry',hex(pos),'shape',hex(shape),'start',hex(start),
          'width',width,'height',height,'area',area)
cursor = 0
for start,pitch,height in layout:
    assert start == cursor
    cursor = start + pitch*height
assert cursor == 0xf850 and len(layout) == 58
assert sum(h for _,_,h in layout) == 2680

wall_start, cpu_start = time.monotonic(), time.process_time()
def checkpoint():
    delay = (time.process_time()-cpu_start)/0.25-(time.monotonic()-wall_start)
    if delay > 0:
        time.sleep(delay)

def reconstruct(mode):
    out = bytearray(s[:65536])
    skip = False
    for start,pitch,height in layout:
        if mode == 'per_image':
            skip = False
        for row in range(height):
            off = start+row*pitch
            pixels = [n for value in s[off:off+pitch] for n in (value >> 4,value & 15)]
            visible = [i for i,n in enumerate(pixels) if n]
            first = visible[0] if visible else len(pixels)
            last = visible[-1] if visible else -1
            for i in range(0,len(pixels),4):
                if (i == 0 if skip else i < first):
                    assert pixels[i] == 0
                    pixels[i] = 15
                if i+3 > last:
                    assert pixels[i+3] == 0
                    pixels[i+3] = 15
            out[off:off+pitch] = bytes((pixels[i] << 4)|pixels[i+1] for i in range(0,len(pixels),2))
            skip = (not skip) and not visible if mode != 'no_state' else False
        checkpoint()
    out[0xf850:] = b'\xff'*(65536-0xf850)
    return bytes(out)

for mode in ('no_state','global','per_image'):
    restored = reconstruct(mode)
    a,b = restored[1::2],restored[::2]
    print(mode,'lane B CRC',f'{zlib.crc32(b):08x}','SHA1',hashlib.sha1(b).hexdigest(),
          'shared exact',restored[0xa1b0:0xa3f0] == f[0x3230:0x3470])
restored = reconstruct('per_image')
a,b = restored[1::2],restored[::2]
files = {'epr-12169.b1':a, 'epr-12170.b5':b,
         'mpr-12194.b1':a+b'\xff'*32768, 'mpr-12195.b5':b+a}
expected = {
 'epr-12169.b1':('dacc6165','87b1a7643e3630ff73b2b117752496e1ea5da23d'),
 'epr-12170.b5':('87354e42','e7fd55aee59b51d82cb9b619fbb815ad6839560c'),
 'mpr-12194.b1':('2fb38880','0e1b601bbda78d1887951c1f7e752531c281bc83'),
 'mpr-12195.b5':('d6a02cba','d80000f92e754e89c6ca7b7273feab448fc9a061')}
for name,data in files.items():
    actual = (f'{zlib.crc32(data):08x}',hashlib.sha1(data).hexdigest())
    assert actual == expected[name],name
    print(name,len(data),*actual)
full = bytearray(131072)
full[::2],full[1::2] = files['mpr-12195.b5'],files['mpr-12194.b1']
assert full.translate(norm) == s
for label,lo,hi in [('graphics',0,0xf850),('tail',0xf850,65536),('second_bank',65536,131072)]:
    changed = sum(((x >> 4) != (y >> 4))+((x & 15) != (y & 15)) for x,y in zip(s[lo:hi],full[lo:hi]))
    assert all(u == v or (u == 0 and v == 15) for x,y in zip(s[lo:hi],full[lo:hi])
               for u,v in ((x >> 4,y >> 4),(x & 15,y & 15)))
    print(label,'changed nibbles',changed)
checkpoint()
# Independently test the marker rule against intact, disc-resident Flash Point.
fd = (folder/'flashpd.p94').read_bytes()
assert len(fd) == 131072
assert hashlib.sha256(fd).hexdigest() == 'b8ae62674eeb20931226efdf095e0a484630643f3be902378a5ec592f717b6b8'
flayout=[]
pos,first_shape = 0xa0c0,len(fd)
while pos+6 <= first_shape:
    shape,start = struct.unpack_from('<IH',fd,pos)
    assert pos+6 <= shape <= len(fd)-4
    first_shape = min(first_shape,shape)
    width,height,area = struct.unpack_from('<BBH',fd,shape)
    assert width and height and width*height == area and width % 2 == 0
    flayout.append((start,width,height))
    pos += 8
assert len(flayout) == 69 and first_shape == 0xa2ea
assert pos == 0xa2e8 and all(b[0] == a[0]+a[1]*a[2] for a,b in zip(flayout,flayout[1:]))
assert flayout[0][0] == 0 and flayout[-1][0]+flayout[-1][1]*flayout[-1][2] == 0xa7e6
print('Flash Point disc table: 69 contiguous images, rows',sum(h for _,_,h in flayout))
assert flayout[1] == (0x30,64,40) and flayout[2] == (0xa30,64,40)
assert not any(f[0x9f0:0xa30].translate(norm))
boundary_pixels=[n for v in f[0xa30:0xa70] for n in (v >> 4,v & 15)]
assert next(i for i,n in enumerate(boundary_pixels) if n not in (0,15)) == 53
assert [i for i in range(0,128,4) if boundary_pixels[i] == 15] == list(range(0,53,4))
print('Image-boundary example: prior final row blank; next first row has 14 left markers')
for mode in ('no_state','global','per_image'):
    skip=False
    stats=dict(images=0,rows=0,row_matches=0,blank=0,blank_matches=0,
               after_blank=0,after_blank_matches=0,changed_nibbles=0)
    examples=[]
    for image,(start,width,height) in enumerate(flayout):
        if mode == 'per_image': skip=False
        intact=f[start:start+width*height]
        damaged=intact.translate(norm)
        image_matches=True
        previous_blank=False
        for row in range(height):
            a=damaged[row*width:(row+1)*width]
            original=intact[row*width:(row+1)*width]
            pixels=[n for v in a for n in (v >> 4,v & 15)]
            visible=[i for i,n in enumerate(pixels) if n]
            first=visible[0] if visible else len(pixels)
            last=visible[-1] if visible else -1
            for i in range(0,len(pixels),4):
                if (i == 0 if skip else i < first):
                    assert pixels[i] == 0
                    pixels[i]=15
                if i+3 > last:
                    assert pixels[i+3] == 0
                    pixels[i+3]=15
            result=bytes((pixels[i] << 4)|pixels[i+1] for i in range(0,len(pixels),2))
            same=result == original
            stats['rows']+=1
            stats['row_matches']+=same
            stats['blank']+=not visible
            stats['blank_matches']+=(not visible) and same
            stats['after_blank']+=previous_blank
            stats['after_blank_matches']+=previous_blank and same
            stats['changed_nibbles']+=sum(((x >> 4)!=(y >> 4))+((x & 15)!=(y & 15)) for x,y in zip(a,result))
            if not same and len(examples)<3:
                examples.append((image,row,hex(start+row*width)))
            image_matches &= same
            previous_blank=not visible
            skip=(not skip) and not visible if mode != 'no_state' else False
        stats['images']+=image_matches
        checkpoint()
    print('Flash Point',mode,stats,'first mismatches',examples)
    if mode == 'per_image':
        assert stats['images'] == 69 and stats['rows'] == stats['row_matches'] == 1967
        assert stats['blank'] == stats['blank_matches'] == 141
        assert stats['after_blank'] == stats['after_blank_matches']
checkpoint()
print('PASS: 4 ROM hashes, source round trip, and intact Flash Point comparison; no ROM files written')
```
